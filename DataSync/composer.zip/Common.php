<?php

/**
 * Created by PhpStorm.
 * User: zzq
 * Date: 2018/5/2
 * Time: 16:57
 */
class Common
{


    public function __construct()
    {

    }
    public static  function getCert($certPath,$certPassword)
    {
        $certPath = 'EduGraphAPI App Only Cert.pfx';
        $certPassword = 'J48W23RQeZv85vj';
        $certs = array();
        $pkcs12 = file_get_contents($certPath );
        openssl_pkcs12_read( $pkcs12, $certs, $certPassword );
        return  $certs ;
    }
}