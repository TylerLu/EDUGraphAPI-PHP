<?php
class DBHelper {
    public $connection=null;
    public $databaseName = null;
    public $username=null;
    public $password=null;
    public $hostName=null;


    public function __construct() {
        $this->databaseName = getenv('DB_DATABASE');
        $this->username=getenv("DB_USERNAME");
        $this->password=getenv("DB_PASSWORD");
        $this->hostName=getenv("DB_HOST");
        $this->connection=mysqli_connect($this->hostName,$this->username,$this->password,$this->databaseName);
        if (!$this->connection) {
            mysqli_error($this->connection);
        }
        mysqli_query($this->connection, "set names utf8") or die(mysqli_error($this->connection));
    }


    public function execute($sql) {
        $result=mysqli_query($this->connection,$sql) or die(mysqli_error($this->connection));
        return $result;
    }

}