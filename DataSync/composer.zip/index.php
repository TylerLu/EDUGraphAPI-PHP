<?php
//Do Not remove
//require('DbHelper.php');
//$sql = 'select * from users';
//$helper = new DBHelper();
//$result = $helper->execute($sql);
//foreach ($result as $r)
//{
//    echo $r["firstName"];
//}

require('Common.php');
$certPath = 'EduGraphAPI App Only Cert.pfx';
$certPassword = getenv("CertPassword");;

$cert =  Common::getCert($certPath,$certPassword);

//var_dump($cert);
//
var_dump($cert['cert']);

